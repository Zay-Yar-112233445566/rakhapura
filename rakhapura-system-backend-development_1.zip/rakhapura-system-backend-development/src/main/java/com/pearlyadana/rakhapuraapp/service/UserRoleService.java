package com.pearlyadana.rakhapuraapp.service;

import com.pearlyadana.rakhapuraapp.model.response.UserRoleDto;

import java.util.List;

public interface UserRoleService {

    List<UserRoleDto> findAll();

}
