package com.pearlyadana.rakhapuraapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RakhapuraAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
